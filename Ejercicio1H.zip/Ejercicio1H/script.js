const arrayHe = {
    paletas: "15",
    paletaCrema: "25",
    BoteHelados: "45",
    BoteNapolitano:"50"
};

let paletas = arrayHe.paletas;
let paletaCrema = arrayHe.paletaCrema;
let BoteHelados = arrayHe.BoteHelados;
let BoteNapolitano = arrayHe.BoteNapolitano;


var luis = parseInt(prompt("Ingrese pago: [LUIS] "));

let cambio1 = luis - paletas;
let cambio2 = luis - paletaCrema;
let cambio3 = luis - BoteHelados;
let cambio4 = luis - BoteNapolitano;

let devo1 = luis - 0;

if(luis >=1 && luis <=14){
    alert(`No le alcanza para nada`);
};
if(luis >= 15 && luis <=24 ){
    let dec1 = parseInt(prompt("¿Que desea comprar? FRESA [1] O UVA[2] NADA[3]"));
    
    if (dec1 === 1) {
        alert(`USTED ELIGIO FRESA, SU CAMBIO ES: ${cambio1}`)
    } else if (dec1 === 2){
        alert(`USTED ELIGIO UVA, SU CAMBIO ES: ${cambio1}`)
    }else if (dec1 ===3){
        alert(`VAYASEALABERGA CON SU CAMBIO: ${devo1}`)
    }
};
if(luis >= 25 && luis <=44 ){
    let dec2 = parseInt(prompt("¿Que desea comprar? BOTE HELADO DE CREMA 1L [1] NADA[2]"));
    
    if (dec2 === 1) {
        alert(`GRACIAS POR SU COMPRA, SU CAMBIO ES: ${cambio2}`)
    }else if (dec2 ===2){
        alert(`VAYASEALABERGA CON SU CAMBIO: ${devo1}`)
    }
};
if(luis >= 45 && luis <=49 ){
    let dec3 = parseInt(prompt("¿Que desea comprar? HELADO DE FRESA [1] O HELADO DE YOGUR[2] NADA[3]"));
    
    if (dec3 === 1) {
        alert(`USTED ELIGIO FRESA, SU CAMBIO ES: ${cambio3}`)
    } else if (dec3 === 2){
        alert(`USTED ELIGIO YOGUR, SU CAMBIO ES: ${cambio3}`)
    }else if (dec3 ===3){
        alert(`VAYASEALABERGA CON SU CAMBIO: ${devo1}`)
    }
};
if(luis >= 50){
    let dec4 = parseInt(prompt("¿Que desea comprar? BOTE HELADO NAPOLITANO 1L [1] NADA[2]"));
    
    if (dec4 === 1) {
        alert(`GRACIAS POR SU COMPRA, SU CAMBIO ES: ${cambio4}`)
    }else if (dec4 ===2){
        alert(`VAYASEALABERGA CON SU CAMBIO: ${devo1}`)
    }
};


var bianca = parseInt(prompt("Ingrese pago: [BIANCA] "));

let cambio5 = bianca - paletas;
let cambio6 = bianca - paletaCrema;
let cambio7 = bianca - BoteHelados;
let cambio8 = bianca - BoteNapolitano;

let devo2 = bianca - 0;

if(bianca >=1 && bianca <=14){
    alert(`No le alcanza para nada`);
};
if(bianca >= 15 && bianca <=24 ){
    let dec5 = parseInt(prompt("¿Que desea comprar? FRESA [1] O UVA[2] NADA[3]"));
    
    if (dec5 === 1) {
        alert(`USTED ELIGIO FRESA, SU CAMBIO ES: ${cambio5}`)
    } else if (dec5 === 2){
        alert(`USTED ELIGIO UVA, SU CAMBIO ES: ${cambio5}`)
    }else if (dec5 ===3){
        alert(`VAYASEALABERGA CON SU CAMBIO: ${devo2}`)
    }
};
if(bianca >= 25 && bianca <=44 ){
    let dec6 = parseInt(prompt("¿Que desea comprar? BOTE HELADO DE CREMA 1L [1] NADA[2]"));
    
    if (dec6 === 1) {
        alert(`GRACIAS POR SU COMPRA, SU CAMBIO ES: ${cambio6}`)
    }else if (dec6 ===2){
        alert(`VAYASEALABERGA CON SU CAMBIO: ${devo2}`)
    }
};
if(bianca >= 45 && bianca <=49 ){
    let dec7 = parseInt(prompt("¿Que desea comprar? HELADO DE FRESA [1] O HELADO DE YOGUR[2] NADA[3]"));
    
    if (dec7 === 1) {
        alert(`USTED ELIGIO FRESA, SU CAMBIO ES: ${cambio7}`)
    } else if (dec7 === 2){
        alert(`USTED ELIGIO YOGUR, SU CAMBIO ES: ${cambio7}`)
    }else if (dec7 ===3){
        alert(`VAYASEALABERGA CON SU CAMBIO: ${devo2}`)
    }
};
if(bianca >= 50){
    let dec8 = parseInt(prompt("¿Que desea comprar? BOTE HELADO NAPOLITANO 1L [1] NADA[2]"));
    
    if (dec8 === 1) {
        alert(`GRACIAS POR SU COMPRA, SU CAMBIO ES: ${cambio8}`)
    }else if (dec8 ===2){
        alert(`VAYASEALABERGA CON SU CAMBIO: ${devo2}`)
    }
};


var valeska = parseInt(prompt("Ingrese pago: [VALESKA] "));

let cambio9 = valeska - paletas;
let cambio10 = valeska - paletaCrema;
let cambio11 = valeska - BoteHelados;
let cambio12 = valeska - BoteNapolitano;

let devo3 = valeska - 0;

if(valeska >=1 && valeska <=14){
    alert(`No le alcanza para nada`);
};
if(valeska >= 15 && valeska <=24 ){
    let dec9 = parseInt(prompt("¿Que desea comprar? FRESA [1] O UVA[2] NADA[3]"));
    
    if (dec9 === 1) {
        alert(`USTED ELIGIO FRESA, SU CAMBIO ES: ${cambio9}`)
    } else if (dec9 === 2){
        alert(`USTED ELIGIO UVA, SU CAMBIO ES: ${cambio9}`)
    }else if (dec9 ===3){
        alert(`VAYASEALABERGA CON SU CAMBIO: ${devo3}`)
    }
};
if(valeska >= 25 && valeska<=44 ){
    let dec10 = parseInt(prompt("¿Que desea comprar? BOTE HELADO DE CREMA 1L [1] NADA[2]"));
    
    if (dec10 === 1) {
        alert(`GRACIAS POR SU COMPRA, SU CAMBIO ES: ${cambio10}`)
    }else if (dec10 ===2){
        alert(`VAYASEALABERGA CON SU CAMBIO: ${devo3}`)
    }
};
if(valeska >= 45 && valeska <=49 ){
    let dec11 = parseInt(prompt("¿Que desea comprar? HELADO DE FRESA [1] O HELADO DE YOGUR[2] NADA[3]"));
    
    if (dec11 === 1) {
        alert(`USTED ELIGIO FRESA, SU CAMBIO ES: ${cambio11}`)
    } else if (dec11 === 2){
        alert(`USTED ELIGIO YOGUR, SU CAMBIO ES: ${cambio11}`)
    }else if (dec11 ===3){
        alert(`VAYASEALABERGA CON SU CAMBIO: ${devo3}`)
    }
};
if(valeska >= 50){
    let dec12 = parseInt(prompt("¿Que desea comprar? BOTE HELADO NAPOLITANO 1L [1] NADA[2]"));
    
    if (dec12 === 1) {
        alert(`GRACIAS POR SU COMPRA, SU CAMBIO ES: ${cambio12}`)
    }else if (dec12 ===2){
        alert(`VAYASEALABERGA CON SU CAMBIO: ${devo3}`)
    }
};
